//
//  AuthViewController.swift
//  LoginFB
//
//  Created by Macbook on 11/23/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class AuthViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var handle : AuthStateDidChangeListenerHandle?
 
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        handle = Auth.auth().addStateDidChangeListener { (auth, users) in
            
           
            
            
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
          let user = Auth.auth().currentUser
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        let user = Auth.auth().currentUser
        

            
        cell.textLabel?.text = user?.displayName as? String
        
        
        return cell
        
        print(UserInfo.self)
        
        viewDidLoad()
        
        
        
    }
    
    
}
