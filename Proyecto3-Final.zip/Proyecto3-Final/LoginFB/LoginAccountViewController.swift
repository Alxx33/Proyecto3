//
//  LoginAccountViewController.swift
//  LoginFB
//
//  Created by Germán Santos Jaimes on 11/7/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class LoginAccountViewController: UIViewController {
    
 
    var handle: AuthStateDidChangeListenerHandle?
    var recibe : String = " "
    let user = Auth.auth().currentUser
    
    @IBOutlet weak var Etiqueta: UILabel!
    
  
    
    @IBAction func logoutUser(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Etiqueta.text = user?.displayName
    
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        handle = Auth.auth().addStateDidChangeListener { (auth,user) in
            
            
//            print(animated)
//            print(user?.email)
//            print(self.recibe)
//            print(Data())
//            print(User.self)
        
        }
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        Auth.auth().removeStateDidChangeListener(handle!)

    }
    
   
    
}
